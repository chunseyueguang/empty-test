#ifndef _UTIL_H
#define _UTIL_H

struct slice{
	char *data;
	int len;
};

#endif
